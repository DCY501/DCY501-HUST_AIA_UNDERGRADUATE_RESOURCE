clc;
clear;
close all;

%% 参数设置
Ts = 0.1; % 采样周期

%% 控制器 D(z)
z = tf('z', Ts);
Dz = (z - 0.006) / (z -0.05);

%% 被控对象 G(s)
s = tf('s');
G_s = 2 / (s * (0.1*s + 1) * (0.05*s + 1));  % 连续系统

%% 零阶保持离散化 G(s)
Gd = c2d(G_s, Ts, 'zoh');

%% 闭环传递函数
sys_cl = feedback(Dz * Gd, 1);

%% 显示系统信息
disp('离散控制器 D(z):');
Dz

disp('ZOH 离散化后的被控对象 G(z):');
Gd

disp('闭环系统传递函数（Discrete）:');
sys_cl

%% 绘制闭环系统阶跃响应
figure;
step(sys_cl, 5);  % 仿真 5 秒
title('闭环系统单位阶跃响应');
xlabel('时间 (秒)');
ylabel('输出 y(t)');
grid on;

%% 生成 Simulink 模型图
model = 'q_feedback_model';
new_system(model);
open_system(model);

% 添加模块
add_block('simulink/Sources/Step', [model '/Step'], 'Position', [30 100 60 130]);
add_block('simulink/Math Operations/Sum', [model '/Sum'], 'Inputs', '+-', 'Position', [100 100 120 130]);
add_block('simulink/Discrete/Discrete Transfer Fcn', [model '/D(z)'], ...
    'Numerator', '[1 -0.006]', 'Denominator', '[1 -0.05]', 'SampleTime', '0.1', 'Position', [150 90 230 140]);
add_block('simulink/Discrete/Zero-Order Hold', [model '/ZOH'], 'SampleTime', '0.1', 'Position', [250 90 280 140]);
add_block('simulink/Continuous/Transfer Fcn', [model '/G(s)'], ...
    'Numerator', '[2]', 'Denominator', '[0.005 0.15 1 0]', 'Position', [300 90 400 140]);
add_block('simulink/Sinks/Scope', [model '/Scope'], 'Position', [460 100 490 130]);
add_block('simulink/Signal Routing/Goto', [model '/Feedback'], 'GotoTag', 'y', 'Position', [500 130 530 160]);
add_block('simulink/Signal Routing/From', [model '/FromFeedback'], 'GotoTag', 'y', 'Position', [10 140 40 170]);

% 连接模块
add_line(model, 'Step/1', 'Sum/1');
add_line(model, 'FromFeedback/1', 'Sum/2');
add_line(model, 'Sum/1', 'D(z)/1');
add_line(model, 'D(z)/1', 'ZOH/1');
add_line(model, 'ZOH/1', 'G(s)/1');
add_line(model, 'G(s)/1', 'Scope/1');
add_line(model, 'G(s)/1', 'Feedback/1');
