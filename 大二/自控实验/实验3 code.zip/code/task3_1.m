% 定义传递函数的参数
K = 2;

% 创建传递函数
num1 = 1;
den1 = [0.1 1];
G1 = tf(num1, den1);

num2 = K;
den2 = [0.05 1];
G2 = tf(num2, den2);

G3 = series(G1, G2);
G = feedback(G3, 1);

% 计算阶跃响应
[y, t] = step(G);
final_value = 2.83;
steady_state_value = y(end);
steady_state_error = final_value - steady_state_value;

% 绘图
figure('Color', [1 1 1]);  % 白色背景
color_order = lines(1);
plot(t, y, 'LineWidth', 2.0, ...
    'Color', color_order(1,:), 'LineStyle', '-');
hold on;

title('系统阶跃响应', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('时间 (s)', 'FontSize', 12);
ylabel('输出响应', 'FontSize', 12);
grid on;
set(gca, 'FontSize', 12);
box on;

% 输出稳态误差
fprintf('稳态误差: %.4fV\n', steady_state_error);
