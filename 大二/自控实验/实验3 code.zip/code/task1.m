function step_response_for_different_R()
    s = tf('s');
    R_values = [4000, 40000, 400000];
    legend_entries = {};
    
    t_end = 10;
    t_step = 0.01;
    t = 0:t_step:t_end;
    
    figure('Color', [1 1 1]);  % 白色背景
    color_order = lines(length(R_values));
    line_styles = {'-', '--', '-.'};
    
    for i = 1:length(R_values)
        R = R_values(i);

        G = (100e3/R) / (0.1*s^2 + s + 100e3/R);

        [y, t_response] = step(G, t);
        plot(t_response, y, 'LineWidth', 2.0, ...
            'Color', color_order(i, :), ...
            'LineStyle', line_styles{mod(i-1, length(line_styles))+1});
        hold on;
        legend_entries{end+1} = ['R = ' num2str(R/1000) 'K\Omega'];
    end

    title('不同电阻值下的振荡环节阶跃响应', 'FontSize', 14, 'FontWeight', 'bold');
    xlabel('时间（秒）', 'FontSize', 12);
    ylabel('响应幅度', 'FontSize', 12);
    legend(legend_entries, 'Location', 'Best', 'FontSize', 10);
    grid on;
    set(gca, 'FontSize', 12);
    box on;
end

step_response_for_different_R();
