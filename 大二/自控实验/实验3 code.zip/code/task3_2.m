% 定义传递函数的参数
K = 1;

% 定义传递函数
num1 = 1;
den1 = [0.1 0];  % 注意积分项
G1 = tf(num1, den1);

num2 = K;
den2 = [0.05 1];
G2 = tf(num2, den2);

G3 = series(G1, G2);
G = feedback(G3, 1);

% 计算阶跃响应
[y, t] = step(G);
steady_state_value = y(end);
final_value = 2.5;
steady_state_error = final_value - steady_state_value;

% 绘制统一风格图像
figure('Color', [1 1 1]);
color_order = lines(1);
plot(t, y, 'LineWidth', 2.0, ...
    'Color', color_order(1,:), 'LineStyle', '-');
hold on;

title('系统阶跃响应', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('时间 (s)', 'FontSize', 12);
ylabel('输出响应', 'FontSize', 12);
grid on;
set(gca, 'FontSize', 12);
box on;

% 显示稳态误差
fprintf('稳态误差: %.4fV\n', steady_state_error);
