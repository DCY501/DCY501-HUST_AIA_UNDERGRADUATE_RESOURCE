% 定义传递函数的参数
K = 1000; % 增益

% 定义α的值
alpha_values = [0.13, 0.33, 0.44, 0.63]; 

% 创建一个新的图形窗口
figure('Color', [1 1 1]); % 设置白色背景

% 用于保存图例标签
legend_entries = {};
color_order = lines(length(alpha_values)); % 获取预定义颜色
line_styles = {'-', '--', '-.', ':'};      % 不同线型

% 循环不同的α值
for i = 1:length(alpha_values)
    a = alpha_values(i); % 当前α值

    num = K;
    den = [1 100*a 1000];
    G = tf(num, den);

    % 绘制阶跃响应（自定义颜色和线型）
    [y, t] = step(G);
    plot(t, y, 'LineWidth', 2.0, ...
        'Color', color_order(i, :), ...
        'LineStyle', line_styles{mod(i-1, length(line_styles))+1});
    hold on;

    % 保存图例名称
    legend_entries{end+1} = ['\alpha = ' num2str(a)];
end

% 添加图注和标题
title('系统阶跃响应对比（不同 \alpha）', 'FontSize', 14, 'FontWeight', 'bold');
xlabel('时间 (s)', 'FontSize', 12);
ylabel('输出响应', 'FontSize', 12);
legend(legend_entries, 'Location', 'Best', 'FontSize', 10);
grid on;
set(gca, 'FontSize', 12); % 坐标轴字体大小
box on; % 显示边框
