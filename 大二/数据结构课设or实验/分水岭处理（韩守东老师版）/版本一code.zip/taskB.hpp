#ifndef taskB_hpp
#define taskB_hpp

#include "taskA.hpp"
int taskBMain(const Mat & markers);

#endif
