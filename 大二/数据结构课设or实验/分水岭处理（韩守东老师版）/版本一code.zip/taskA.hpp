#ifndef taskA_hpp
#define taskA_hpp

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <opencv2/core/utils/logger.hpp>

using namespace cv;
using namespace std;

int taskAMain(Mat & sMkrImage);

#endif
