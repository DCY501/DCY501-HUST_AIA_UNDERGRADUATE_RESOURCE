#include "taskA.hpp"

int seedCount;
// ����Բ�̲���
class PoissonDisk {
    typedef pair<float, float> P;

    // �ж������ɵĵ��Ƿ���Բ��
    bool inCircle(P a, P b, double r) {
        double dx = a.first - b.first;
        double dy = a.second - b.second;
        return dx * dx + dy * dy <= r * r;
    }

    // �ж������ɵĵ��Ƿ�Ϸ�
    bool isValid(int h, int w, float r, float cellSize, P newP, vector<vector<int>>& grid, float& min_distance) {
        if (newP.first < 0 || newP.first > h || newP.second < 0 || newP.second > w) return false;

        int row = int(newP.first / cellSize);
        int col = int(newP.second / cellSize);
        int up = max(0, row - 2);
        int down = min(int(grid.size()) - 1, row + 2);

        int left = max(0, col - 2);
        int right = min(int(grid[0].size()) - 1, col + 2);

        P gridPoint;
        min_distance = 100;
        for (int i = up; i <= down; ++i) {
            for (int j = left; j <= right; ++j) {
                if (grid[i][j] < 0) continue;

                gridPoint = points[grid[i][j]];
                float dist = sqrt(pow(gridPoint.first - newP.first, 2) + pow(gridPoint.second - newP.second, 2));
                if (dist < r)
                    return false;
                if (dist < min_distance) {
                    min_distance = dist;
                }
            }
        }

        return true;
    }

public:
    vector<P> points;
    // ���ɲ�����
    vector<P> sampling(int h, int w) {
        std::srand(time(NULL));
        float r2 = h * w / seedCount;
        float r = sqrt(r2);
        float cellSize = r / sqrt(2);

        // ��ʼ������
        static vector<vector<int>> grid(ceil(h / cellSize), vector<int>(ceil(w / cellSize), -1));

        // ������ɵ�һ����
        P first_point = { 600.0 * rand() / RAND_MAX, 600.0 * rand() / RAND_MAX };
        points.push_back(first_point);
        grid[int(first_point.first / cellSize)][int(first_point.second / cellSize)] = 0;
        int point_num = 1;

        for (int index = 0; index < point_num; index++)
        {
            std::srand(time(NULL));
            for (int point_trail = 0; point_trail < 4; point_trail++) {
                float general_min_distance = 200;
                P general_min_point;
                bool generated = false;
                for (int i = 0; i < 40; ++i) {
                    float min_distance = 110;
                    float theta = 2 * CV_PI * rand() / RAND_MAX;
                    float rho = r * 0.02 * rand() / RAND_MAX;

                    P newP;
                    newP.first = points[index].first + (r + rho) * cos(theta);
                    newP.second = points[index].second + (r + rho) * sin(theta);

                    bool res = isValid(h, w, r, cellSize, newP, grid, min_distance);
                    if (!res)
                        continue;

                    if (min_distance < general_min_distance) {
                        general_min_distance = min_distance;
                        general_min_point.first = newP.first;
                        general_min_point.second = newP.second;
                        generated = true;
                    }
                }
                if (generated) {
                    grid[int(general_min_point.first / cellSize)][int(general_min_point.second / cellSize)] = points.size();
                    points.push_back(general_min_point);
                    point_num++;
                }
            }
        }
        return points;
    }
};


void generateSeeds(Mat& image, vector<Point>& seedPoints) {
    // ����������ӵ�

    int test = 0;
    PoissonDisk poissonDisk;

    vector<pair<float, float>> seeds = poissonDisk.sampling(image.cols, image.rows);
    test = 1;
    for (size_t i = 0; i < seeds.size(); ++i) {
        Point seedPoint(seeds[i].first, seeds[i].second);
        //circle(image, seedPoint, sqrt((image.rows * image.cols) / seedCount), Scalar(0, 0, 255), 1);
        circle(image, seedPoint, 1, Scalar(0, 0, 255), -1);

        //putText(image, to_string(i), seedPoint, FONT_HERSHEY_PLAIN, 0.5, Scalar(0, 255, 0), 1);
        seedPoints.push_back(seedPoint);
    }
}

void watershedWithOverlay(Mat& inputImage, const vector<Point>& seedPoints, Mat& outputImage, Mat& markers) {
    // ��ˮ���㷨
    Mat grayImage;
    cvtColor(inputImage, grayImage, COLOR_BGR2GRAY);
    threshold(grayImage, grayImage, 0, 255, THRESH_BINARY_INV | THRESH_OTSU);

    markers = Mat::zeros(inputImage.size(), CV_32S);

    for (size_t i = 0; i < seedPoints.size(); ++i) {
        markers.at<int>(seedPoints[i]) = i + 1; // Ϊÿ�����ӵ���䲻ͬ�ı�ǩֵ
    }

    watershed(inputImage, markers);
    vector<Vec3b> colors(seedPoints.size());
    for (size_t i = 0; i < seedPoints.size(); ++i) {
        colors[i] = Vec3b(rand() % 256, rand() % 256, rand() % 256);
    }

    for (int i = 0; i < markers.rows; ++i) {
        for (int j = 0; j < markers.cols; ++j) {
            int index = markers.at<int>(i, j);
            if (index > 0) {
                Vec3b& color = colors[index - 1];
                Vec3b& pixel = outputImage.at<Vec3b>(i, j);
                pixel = pixel * 0.5 + color * 0.5;
            }
        }
    }
}

int taskAMain(Mat& sMkrImage) {

    cv::utils::logging::setLogLevel(utils::logging::LOG_LEVEL_SILENT);
    Mat srcImage = imread("3.jpg");
    if (srcImage.empty()) {
        cerr << "�޷�����ͼ��" << endl;
        return -1;
    }
    cout << "���������ӵ�����";
    cin >> seedCount;
    clock_t start = clock();
    Mat seedImage = srcImage.clone();
    vector<Point> seedPoints;
    // �������ӵ�
    generateSeeds(seedImage, seedPoints);

    Mat watershedImage = srcImage.clone();
    // ��ˮ���㷨
    watershedWithOverlay(srcImage, seedPoints, watershedImage, sMkrImage);
    imshow("Seed Image", seedImage);
    imshow("Watershed Image", watershedImage);
    clock_t end = clock();
    double elapsed_secs = double(end - start) / CLOCKS_PER_SEC;
    cout << "����A����ʱ�䣺" << elapsed_secs << "��" << endl;

    waitKey(0);
    seedCount += 100;
    return 0;
}