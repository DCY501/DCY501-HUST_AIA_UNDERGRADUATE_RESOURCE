#ifndef taskC_hpp
#define taskC_hpp

#include "taskA.hpp"

int taskCMain(const Mat & marker);

#endif
